var gfm = gfm || {};

gfm.Vec4 = function(x, y, z, w)
{
    this._x = x;
    this._y = y;
    this._z = z;
    this._w = w;    
};
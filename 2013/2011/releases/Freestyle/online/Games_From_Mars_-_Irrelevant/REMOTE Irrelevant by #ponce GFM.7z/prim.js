var gfm = gfm || {};

gfm.MAX_PRIMS = 1000;


gfm.Prim = function(x, y, z, radius, r, g, b)
{
    this._x = x;
    this._y = y;
    this._z = z;
    this._radius = radius;
    this._r = r;
    this._g = g;
    this._b = b;
    this._stroke = false;
};


gfm.Prim.prototype = {
    
    
    
    
    
    
};
  
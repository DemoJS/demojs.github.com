9 MINUTES TO DEADLINE NO TIME FOR THIS

just a quickie prod with Canvas, abusing radial gradient
best played with Chrome

#ponce^gfm
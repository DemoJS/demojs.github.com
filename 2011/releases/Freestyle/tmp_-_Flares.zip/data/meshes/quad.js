meshArrays.quad = new Float32Array([
	-1.0, -1.0,
	-1.0, 1.0,
	1.0, 1.0,
	1.0, 1.0,
	1.0, -1.0,
	-1.0, -1.0
])
